
package com.carservicing;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.carservicing.models.Admin;
import com.carservicing.models.Customer;

@SpringBootTest
class CarServicingApplicationTests {

	Admin admin; 
	Customer customer;
	
	@BeforeEach
	void setUp() throws Exception{
		admin= new Admin();
		admin.setUserid("admin");
		admin.setUname("Administrator");
		admin.setPwd("admin");
		
		customer=new Customer();
		customer.setFname("Aman");
		customer.setLname("Akash");
		customer.setEmail("contactakash8@gmail.com");
		customer.setPhone("1234567890");
	}
	
	
	@Test
	void testgetUserid() {
		assertEquals("admin",admin.getUserid());
	}
	@Test
	void testgetUname() {
		assertEquals("Administrator",admin.getUname());
	}
	@Test
	void testgetPwd() {
		assertEquals("admin",admin.getPwd());
	}
	@Test
	void testgetFname() {
		assertEquals("Aman",customer.getFname());
	}
	
	@Test
	void testgetLname() {
		assertEquals("Akash",customer.getLname());
	}
	@Test
	void testgetEmail() {
		assertEquals("contactakash8@gmail.com",customer.getEmail());
	}
	@Test
	void testgetPhone() {
		assertEquals("1234567890",customer.getPhone());
	}
	
}