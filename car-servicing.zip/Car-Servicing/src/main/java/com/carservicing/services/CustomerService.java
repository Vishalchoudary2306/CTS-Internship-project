package com.carservicing.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carservicing.models.Customer;
import com.carservicing.repos.CustomerRepository;

@Service
public class CustomerService {

	@Autowired private CustomerRepository repo;
	
	public void save(Customer customer) {
		repo.save(customer);
	}
	
	public List<Customer> listall(){
		return repo.findAll();
	}
	
	public Customer findbyid(int id) {
		return repo.findById(id).orElse(null);
	}
	
	public Customer validate(String userid,String pwd) {
		Customer v=repo.findByEmail(userid);
		if(v!=null && v.getPwd().equals(pwd))
			return v;
		return null;
	}
}