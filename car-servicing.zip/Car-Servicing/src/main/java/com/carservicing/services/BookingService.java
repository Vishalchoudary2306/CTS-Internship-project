package com.carservicing.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carservicing.models.Booking;
import com.carservicing.models.Payment;
import com.carservicing.models.PaymentDTO;
import com.carservicing.models.ServiceItem;
import com.carservicing.models.ServiceItemDTO;
import com.carservicing.repos.BookingRepository;
import com.carservicing.repos.PaymentRepository;
import com.carservicing.repos.ServiceItemRepository;

@Service
public class BookingService {

	@Autowired private BookingRepository repo;
	@Autowired private VendorService vservice;
	@Autowired private CustomerService cservice;
	@Autowired private ServiceCenterService scservice;
	@Autowired private ServiceItemRepository srepo;
	@Autowired private PaymentRepository prepo;
	
	public void save(Booking booking) {
		repo.save(booking);
	}
	
	public Booking findById(int id) {
		return repo.findById(id).get();
	}
	
	public List<Booking> findCenterBooking(int vendorid){
		return repo.findByVendor(vservice.findbyid(vendorid));
	}
	
	public List<Booking> findCustomerBooking(int custid){
		return repo.findByCustomer(cservice.findbyid(custid));
	}
	
	public void updateStatus(int id,String status,String reason,int scid) {
		Booking bk=repo.findById(id).get();
		bk.setStatus(status);
		bk.setReason(reason);
		if(scid!=0)
			bk.setCenter(scservice.findById(scid));
		repo.save(bk);
	}
	
	public void saveItem(ServiceItemDTO dto) {
		ServiceItem si=new ServiceItem();
		si.setAmount(dto.getAmount());
		si.setName(dto.getName());
		si.setBooking(findById(dto.getBookingid()));
		srepo.save(si);
	}
	
	public void deleteItem(int id) {
		srepo.deleteById(id);
	}
	
	public void savePayment(PaymentDTO dto) {
		Payment pmt=new Payment();
		pmt.setAmount(dto.getAmount());
		pmt.setCardno(dto.getCardno());
		pmt.setNameoncard(dto.getNameoncard());
		pmt.setBooking(findById(dto.getBookingid()));
		prepo.save(pmt);
	}
}
