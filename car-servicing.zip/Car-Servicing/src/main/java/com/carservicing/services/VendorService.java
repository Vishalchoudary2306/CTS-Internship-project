package com.carservicing.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carservicing.models.Vendor;
import com.carservicing.repos.VendorRepository;

@Service
public class VendorService {

	@Autowired private VendorRepository repo;
	
	public void save(Vendor vendor) {
		repo.save(vendor);
	}
	
	public List<Vendor> listall(){
		return repo.findAll();
	}
	
	public Vendor findbyid(int id) {
		return repo.findById(id).orElse(null);
	}
	
	public void activate(int id) {
		Vendor v=findbyid(id);
		v.setIsactive(true);
		repo.save(v);
	}
	
	public void deactivate(int id) {
		Vendor v=findbyid(id);
		v.setIsactive(false);
		repo.save(v);
	}
	
	public Vendor validate(String userid,String pwd) {
		Vendor v=repo.findByEmail(userid);
		if(v!=null && v.getPwd().equals(pwd))
			return v;
		return null;
	}
}