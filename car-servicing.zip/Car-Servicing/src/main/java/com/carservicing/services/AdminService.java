package com.carservicing.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carservicing.models.Admin;
import com.carservicing.repos.AdminRepository;

@Service
public class AdminService {

	@Autowired private AdminRepository repo;
	
	public Admin validate(String userid,String pwd) {
		Admin a=repo.findById(userid).orElse(null);
		if(a!=null && a.getPwd().equals(pwd))
			return a;
		return null;
	}
	
	public void register() {
		if(repo.count()==0) {
			Admin admin=new Admin("admin", "admin", "Administrator");
			repo.save(admin);
		}
	}
}
