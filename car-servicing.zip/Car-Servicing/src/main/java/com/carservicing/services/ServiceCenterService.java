package com.carservicing.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carservicing.models.ServiceCenter;
import com.carservicing.repos.ServiceCenterRepository;

@Service
public class ServiceCenterService {

	@Autowired private ServiceCenterRepository repo;
	@Autowired private VendorService vservice;
	
	public void save(ServiceCenter sc) {
		repo.save(sc);
	}
	
	public List<ServiceCenter> findAll(int id){
		return repo.findByVendor(vservice.findbyid(id));
	}
	
	public List<ServiceCenter> allCenters(){
		return repo.findAll();
	}
	
	public List<ServiceCenter> findCenters(String type,String text){
		switch(type) {
			case "Name":
				return repo.findByCenterNameContaining(text);
			case "Location":
				return repo.findByAddressContaining(text);
			case "Service":
				return repo.findByServiceTypeContaining(text);
		}
		return null;
	}
	
	public void deleteById(int id) {
		repo.deleteById(id);
	}
	
	public ServiceCenter findById(int id) {
		return repo.findById(id).orElse(null);
	}
}
