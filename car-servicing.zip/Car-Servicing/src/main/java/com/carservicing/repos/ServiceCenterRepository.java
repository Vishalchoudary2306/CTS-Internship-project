package com.carservicing.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.carservicing.models.ServiceCenter;
import com.carservicing.models.Vendor;

@Repository
public interface ServiceCenterRepository extends JpaRepository<ServiceCenter, Integer> {

	List<ServiceCenter> findByVendor(Vendor v);
	List<ServiceCenter> findByCenterNameContaining(String name);
	List<ServiceCenter> findByServiceTypeContaining(String name);
	List<ServiceCenter> findByAddressContaining(String name);
}
