package com.carservicing.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.carservicing.models.Booking;
import com.carservicing.models.Customer;
import com.carservicing.models.Vendor;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Integer> {

	List<Booking> findByVendor(Vendor vendor);
	List<Booking> findByCustomer(Customer cust);
	
}
