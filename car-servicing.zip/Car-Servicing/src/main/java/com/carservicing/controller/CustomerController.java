package com.carservicing.controller;

import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.carservicing.models.Booking;
import com.carservicing.models.PaymentDTO;
import com.carservicing.models.ServiceCenter;
import com.carservicing.services.BookingService;
import com.carservicing.services.CustomerService;
import com.carservicing.services.ServiceCenterService;

@Controller
public class CustomerController {

	@Autowired private HttpSession session;
	@Autowired private CustomerService cservice;
	@Autowired private BookingService bservice;
	@Autowired private ServiceCenterService scservice;
	
	@GetMapping("profile")
	public String profile(Model model) {
		int custid=(int)session.getAttribute("id");
		model.addAttribute("c", cservice.findbyid(custid));
		return "profile";
	}
	
	@GetMapping("services")
	public String searchCenters(Optional<String> searchtype,Optional<String> search, Model model) {
		if(search.isPresent()) {
			model.addAttribute("list", scservice.findCenters(searchtype.get(), search.get()));
		}else {
			model.addAttribute("list", scservice.allCenters());
		}
		return "services";
	}
	
	@GetMapping("booknow/{id}")
	public String createbooking(@PathVariable("id") int id,Model model) {
		model.addAttribute("sc", scservice.findById(id));
		return "createbooking";
	}
	
	@GetMapping("cancel/{id}")
	public String updateStatus(@PathVariable("id")int id,RedirectAttributes ra) {
		bservice.updateStatus(id, "Cancelled",null,0);
		ra.addFlashAttribute("msg", "Booking Cancelled");
		return "redirect:/mybookings";
	}
	
	@PostMapping("booknow/{id}")
	public String processbooking(@PathVariable("id")int id,Booking booking) {
		ServiceCenter center=scservice.findById(id);
		booking.setCenter(center);
		booking.setId(0);
		booking.setVendor(center.getVendor());
		int custid=(int)session.getAttribute("id");
		booking.setCustomer(cservice.findbyid(custid));
		bservice.save(booking);
		return "redirect:/mybookings";
	}
	
	@GetMapping("bdetails/{id}")
	public String mybookingdetails(@PathVariable("id")int id, Model model) {
		model.addAttribute("bk", bservice.findById(id));
		return "bkdetails";
	}
	
	@GetMapping("mybookings")
	public String mybookings(Model model) {
		int custid=(int)session.getAttribute("id");
		model.addAttribute("list", bservice.findCustomerBooking(custid));
		return "bookings";
	}
	
	@GetMapping("updatestatus")
	public String updateStatus(int id,String status,RedirectAttributes ra) {
		bservice.updateStatus(id, status,null,0);
		ra.addFlashAttribute("msg", "Booking approved");
		return "redirect:/mybookings";
	}
	
	@PostMapping("payment")
	public String payment(PaymentDTO dto) {
		bservice.savePayment(dto);
		bservice.updateStatus(dto.getBookingid(), "Paid",null,0);
		return "redirect:/mybookings";
	}
}
