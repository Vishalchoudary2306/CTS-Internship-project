package com.carservicing.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.carservicing.models.Admin;
import com.carservicing.models.Customer;
import com.carservicing.models.Vendor;
import com.carservicing.services.AdminService;
import com.carservicing.services.CustomerService;
import com.carservicing.services.VendorService;

@Controller
public class AdminController {

	@Autowired private AdminService aservice;
	@Autowired private VendorService vservice;
	@Autowired private CustomerService cservice;
	@Autowired private HttpSession session;
	
	
	@PostMapping("/validate")
	public String validate(String userid,String pwd,String role,RedirectAttributes ra) {
		switch(role)
		{
		case "Admin":
			Admin admin=aservice.validate(userid, pwd);
			if(admin==null) {
				ra.addFlashAttribute("error", "Invalid username or password");
				return "redirect:/";
			}else {
				session.setAttribute("uname", admin.getUname());
				session.setAttribute("role", role);
				return "redirect:/dashboard";
			}
		case "Vendor":
			Vendor v=vservice.validate(userid, pwd);
			if(v!=null && v.isIsactive()) {
				session.setAttribute("uname", v.getFname());
				session.setAttribute("role", role);
				session.setAttribute("id", v.getId());
				return "redirect:/dashboard";
			}else {
				ra.addFlashAttribute("error", "Invalid username or password");
				return "redirect:/";
			}
		case "Customer":
			Customer c=cservice.validate(userid, pwd);
			if(c!=null) {
				session.setAttribute("uname", c.getFname());
				session.setAttribute("role", role);
				session.setAttribute("id", c.getId());
				return "redirect:/profile";
			}else {
				ra.addFlashAttribute("error", "Invalid username or password");
				return "redirect:/";
			}
		}
		return "redirect:/";
	}
	
	@GetMapping("vendors")
	public String vendorlist(Model model) {
		model.addAttribute("list", vservice.listall());
		return "vendors";
	}
	
	@GetMapping("activate/{id}")
	public String activate(@PathVariable("id") int id,RedirectAttributes ra) {
		vservice.activate(id);
		ra.addFlashAttribute("msg", "Vendor activated");
		return "redirect:/vendors";
	}
	
	@GetMapping("deactivate/{id}")
	public String deactivate(@PathVariable("id") int id,RedirectAttributes ra) {
		vservice.deactivate(id);
		ra.addFlashAttribute("msg", "Vendor deactivated");
		return "redirect:/vendors";
	}
	
	@GetMapping("customers")
	public String customerlist(Model model) {
		model.addAttribute("list", cservice.listall());
		return "customers";
	}
	
	@PostMapping("cregister")
	public String savecustomer(Customer customer) {
		cservice.save(customer);
		return "redirect:/";
	}
	
	@PostMapping("register")
	public String regsiter(Vendor vendor) {
		vservice.save(vendor);
		return "redirect:/";
	}
	
	@GetMapping("dashboard")
	public String dashboard() {
		return "adashboard";
	}
	
}
