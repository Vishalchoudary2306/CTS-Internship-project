package com.carservicing.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.carservicing.models.Booking;
import com.carservicing.models.ServiceCenter;
import com.carservicing.models.ServiceItemDTO;
import com.carservicing.models.Vendor;
import com.carservicing.services.BookingService;
import com.carservicing.services.ServiceCenterService;
import com.carservicing.services.VendorService;

@Controller
public class VendorController {

	@Autowired private HttpSession session;
	@Autowired private VendorService vservice;
	@Autowired private BookingService bservice;
	@Autowired private ServiceCenterService cservice;
	
	@GetMapping("/vprofile")
	public String vendorprofile(Model model) {
		int id=(int)session.getAttribute("id");
		model.addAttribute("v",vservice.findbyid(id));
		return "vprofile";
	}
	
	@PostMapping("/vprofile")
	public String updateprofile(Vendor v,RedirectAttributes ra) {
		int id=(int)session.getAttribute("id");
		v.setId(id);
		v.setIsactive(true);
		vservice.save(v);
		ra.addFlashAttribute("msg", "Profile updated");
		return "redirect:/vprofile";
	}
	
	@GetMapping("centers")
	public String allcenters(Model model) {
		int id=(int)session.getAttribute("id");
		model.addAttribute("list", cservice.findAll(id));
		return "centers";
	}
	
	@PostMapping("centers")
	public String saveCenter(ServiceCenter sc,RedirectAttributes ra) {
		int id=(int)session.getAttribute("id");
		sc.setVendor(vservice.findbyid(id));
		cservice.save(sc);
		return "redirect:/centers";
	}
	
	@GetMapping("/editcenter/{id}")
	public String editCenter(@PathVariable("id") int id,Model model) {
		model.addAttribute("c", cservice.findById(id));
		return "editcenter";
	}
	
	@PostMapping("/editcenter/{id}")
	public String updateCenter(@PathVariable("id") int id,ServiceCenter sc,RedirectAttributes ra) {
		sc.setId(id);
		int vid=(int)session.getAttribute("id");
		sc.setVendor(vservice.findbyid(vid));
		cservice.save(sc);
		ra.addFlashAttribute("msg", "Center updated");
		return "redirect:/centers";
	}
	
	@GetMapping("bookings")
	public String mybookings(Model model) {
		int vendorid=(int)session.getAttribute("id");
		model.addAttribute("list", bservice.findCenterBooking(vendorid));
		return "bookings";
	}
	
	@GetMapping("details/{id}")
	public String mybookings(@PathVariable("id")int id, Model model) {
		model.addAttribute("bk", bservice.findById(id));
		int vid=(int)session.getAttribute("id");
		model.addAttribute("centers", cservice.findAll(vid));
		return "bookingdetails";
	}
	
	@GetMapping("startservice/{id}")
	public String startservice(@PathVariable("id")int id, Model model) {
		Booking bk=bservice.findById(id);
		model.addAttribute("bk",bk );
		model.addAttribute("total", bk.getItems().stream().map(x->x.getAmount())
				.reduce(0.0,(a,b)->a+b));
		return "startservice";
	}
	
	@PostMapping("addserviceitem")
	public String addserviceitem(ServiceItemDTO dto) {
		bservice.saveItem(dto);
		return  "redirect:/startservice/"+dto.getBookingid();
	}
	
	@GetMapping("deleteitem/{bid}/{id}")
	public String deleteserviceitem(@PathVariable("bid")int bid,@PathVariable("id")int id) {
		bservice.deleteItem(id);
		return "redirect:/startservice/"+bid;
	}
	
	@GetMapping("approve/{id}")
	public String updateStatus(@PathVariable("id")int id,RedirectAttributes ra) {
		bservice.updateStatus(id, "Approved by Vendor",null,0);
		ra.addFlashAttribute("msg", "Booking approved");
		return "redirect:/bookings";
	}
	
	@GetMapping("complete/{id}")
	public String servicecomplete(@PathVariable("id")int id,RedirectAttributes ra) {
		bservice.updateStatus(id, "Billed",null,0);
		ra.addFlashAttribute("msg", "Booking completed");
		return "redirect:/bookings";
	}
	
	@GetMapping("viewbill/{id}")
	public String viewbill(@PathVariable("id")int id,Model model) {
		Booking bk=bservice.findById(id);
		model.addAttribute("bk",bk );
		model.addAttribute("total", bk.getItems().stream().map(x->x.getAmount())
				.reduce(0.0,(a,b)->a+b));
		return "viewbill";
	}
	
	@PostMapping("reject")
	public String rejectbyvendor(String id,String reason,RedirectAttributes ra) {
		bservice.updateStatus(Integer.parseInt(id), "Rejected by Vendor",reason,0);
		ra.addFlashAttribute("msg", "Booking rejected by vendor");
		return "redirect:/bookings";
	}
	
	@PostMapping("reallocate")
	public String reallocatebyvendor(int id,String reason,int scid,RedirectAttributes ra) {
		bservice.updateStatus(id, "Reallocated",reason,scid);
		ra.addFlashAttribute("msg", "Booking reallocated by vendor");
		return "redirect:/bookings";
	}
}
