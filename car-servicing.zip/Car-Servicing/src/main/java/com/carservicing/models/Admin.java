package com.carservicing.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Admin {
	@Id
	@Column(length = 30)
	private String userid;
	
	@Column(length = 30)
	private String pwd;
	
	@Column(length = 30)
	private String uname;
	
	public Admin() {
		// TODO Auto-generated constructor stub
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public Admin(String userid, String pwd, String uname) {
		this.userid = userid;
		this.pwd = pwd;
		this.uname = uname;
	}
	
	
	
}
