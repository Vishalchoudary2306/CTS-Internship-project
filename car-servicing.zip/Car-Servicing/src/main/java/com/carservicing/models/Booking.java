package com.carservicing.models;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

@Entity
public class Booking {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private LocalDate date;
	private LocalTime slot;
	private String address;
	private String phone;
	private String serviceType;
	@JsonFormat(shape = Shape.STRING, pattern = "yyyy-MM-dd")
	private LocalDate bookdate;
	private String status;
	private String reason;
	private String dropby; //Self or Service Center
	
	@ManyToOne
	@JoinColumn(name="customer_id")
	private Customer customer;
	@ManyToOne
	@JoinColumn(name="vendor_id")
	private Vendor vendor;
	@ManyToOne
	@JoinColumn(name="center_id")
	private ServiceCenter center;
	
	@OneToMany(mappedBy = "booking",fetch = FetchType.LAZY)
	@Fetch(FetchMode.SUBSELECT)
	private List<ServiceItem> items;
	
	@OneToOne(mappedBy = "booking",fetch = FetchType.LAZY)
	@Fetch(FetchMode.JOIN)
	private Payment payment;
	
	public Booking() {
		this.bookdate=LocalDate.now();
		this.status="Booked";
	}
	
	public List<ServiceItem> getItems() {
		return items;
	}
	
	public Payment getPayment() {
		return payment;
	}

	public void setPayment(Payment payment) {
		this.payment = payment;
	}

	public void setItems(List<ServiceItem> items) {
		this.items = items;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}

	public void setBookdate(LocalDate bookdate) {
		this.bookdate = bookdate;
	}

	public String getDropby() {
		return dropby;
	}

	public void setDropby(String dropby) {
		this.dropby = dropby;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = LocalDate.parse(date);
	}
	public LocalTime getSlot() {
		return slot;
	}
	public void setSlot(String slot) {
		this.slot = LocalTime.parse(slot);
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public LocalDate getBookdate() {
		return bookdate;
	}
	public void setBookdate(String bookdate) {
		this.bookdate = LocalDate.parse(bookdate);
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Vendor getVendor() {
		return vendor;
	}
	public void setVendor(Vendor vendor) {
		this.vendor = vendor;
	}
	public ServiceCenter getCenter() {
		return center;
	}
	public void setCenter(ServiceCenter center) {
		this.center = center;
	}
	
	
}
