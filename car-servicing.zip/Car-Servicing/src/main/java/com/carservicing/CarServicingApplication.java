package com.carservicing;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.carservicing.services.AdminService;

@SpringBootApplication
public class CarServicingApplication {
	
	private static final Logger log = LoggerFactory.getLogger(CarServicingApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(CarServicingApplication.class, args);
	}
	
	@Bean
	public CommandLineRunner demo(AdminService srv) {
	    return (args) -> {
    		srv.register();
    		log.info("Admin user created successfully");
	    };
	}

}
